
// form

const touch__form = document.querySelector('.touch__form');
function retrieveFormValue(event) {

	event.preventDefault();


	const fields = document.querySelectorAll("input");
	const values = {};
	fields.forEach(field => {
		const { name, value } = field;
		values[name] = value;

	});
	console.log(values);
}

touch__form.addEventListener('submit', retrieveFormValue);


// animation
let title = document.querySelector('.element-show');


function onEntry(entry) {
	entry.forEach(change => {
		if (change.isIntersecting) {
			change.target.classList.add('element-active');
		}
	});
}

let options = {
	threshold: [0.5]
};
let observer = new IntersectionObserver(onEntry, options);
let elements = document.querySelectorAll('.element-show');

for (let elm of elements) {
	observer.observe(elm);
}
let cooke = document.querySelector('.cookie ')
let cooke__btn = document.querySelector('.cookie__btn');
cooke.addEventListener('click', () => {
	cooke.style.display = 'none';
});

let btn_mobile = document.querySelector('.mission__cookie-btn');
let cookie__mobile = document.querySelector('.mission__cookie');

btn_mobile.addEventListener('click', () => {
	cookie__mobile.style.display = 'none';
});